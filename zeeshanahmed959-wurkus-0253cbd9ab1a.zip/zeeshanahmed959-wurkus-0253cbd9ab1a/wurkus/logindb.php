<?php
$hn='localhost';
$db='wurkus';
$un='zeeshan';
$pd='test';
?>